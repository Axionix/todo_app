import logo from './logo.svg';
import './App.css';
import TodoList from './components/TodoList';

function App() {
  return (
    <>
    <TodoList></TodoList>
    </>
  );
}

export default App;
